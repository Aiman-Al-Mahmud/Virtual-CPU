#include <iostream>
#include <sstream>
#include <vector>
#include "ALU.h"
#include "Registers.h"
#include "ControlUnit.h"
#include "Memory.h"
#include "InstructionToBinary.h"

using namespace std;

int main() {
    ALU alu;
    Registers registers;
    ControlUnit controlUnit;
    Memory memory;

    int task = 0;
    cout << "Select Task: \n1. Previous Execution Logic\n2. Fetch-Decode-Execute Cycle\n3. Memory Management\nEnter choice: ";
    cin >> task;

    if (task == 1) {
        // Existing Week 1 logic
    } 
    else if (task == 2) {
        vector<string> program = {
            "ADD R0 R1 R2",
            "SUB R1 R0 R3",
            "NOT R2",
            "NOP"
        };
        memory.loadInstructions(program);

        while (controlUnit.getProgramCounter() < program.size()) {
            string instruction = memory.fetchInstruction(controlUnit.getProgramCounter());
            controlUnit.setInstruction(instruction);

            // Decode instruction to binary and display
            string binaryInstruction = assembleInstructionToBinary(instruction);
            cout << "Decoded Instruction (Binary): " << binaryInstruction << endl;

            // Execute instruction
            istringstream instStream(instruction);
            string op, r1, r2, r3;
            instStream >> op;

            if (op == "ADD" || op == "SUB" || op == "AND" || op == "OR") {
                instStream >> r1 >> r2 >> r3;
                int result = alu.execute(op, registers.get(stoi(r2.substr(1))), registers.get(stoi(r3.substr(1))));
                registers.set(stoi(r1.substr(1)), result);
            } else if (op == "NOT") {
                instStream >> r1;
                int result = alu.execute(op, registers.get(stoi(r1.substr(1))));
                registers.set(stoi(r1.substr(1)), result);
            } else if (op == "NOP") {
                // No operation
            }

            controlUnit.incrementProgramCounter();
            registers.print();
        }
    } 
    else if (task == 3) {
        // New Week 5 Memory Management
        cout << "Testing Memory Management:" << endl;

        // Write data
        memory.writeData(memory.mapAddress("data", 5), 42);
        memory.writeData(memory.mapAddress("data", 10), 84);

        // Read data
        cout << "Read Data [Segment: data, Offset: 5]: " << memory.readData(memory.mapAddress("data", 5)) << endl;
        cout << "Read Data [Segment: data, Offset: 10]: " << memory.readData(memory.mapAddress("data", 10)) << endl;

        // Print entire memory
        memory.printMemory();
    } 
    else {
        cout << "Invalid task selected." << endl;
    }

    return 0;
}

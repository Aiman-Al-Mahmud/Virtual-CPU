#ifndef MEMORY_H
#define MEMORY_H

#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
using namespace std;

class Memory {
private:
    vector<int> data;                // Simulated memory data space
    vector<string> instructions;     // Instruction memory
    unordered_map<string, int> segments; // Memory segmentation map

public:
    Memory() : data(256, 0) {        // Initialize with 256 memory slots
        segments["code"] = 0;        // Code segment starts at 0
        segments["data"] = 128;      // Data segment starts at 128
    }

    // Load instructions into memory
    void loadInstructions(const vector<string>& program) {
        instructions = program;
    }

    // Fetch an instruction at a specific address
    string fetchInstruction(int address) const {
        if (address >= 0 && address < instructions.size()) {
            return instructions[address];
        } else {
            cerr << "Invalid instruction address: " << address << endl;
            return "NOP"; // Return a no-operation if the address is invalid
        }
    }

    // Write to memory
    void writeData(int address, int value) {
        if (address >= 0 && address < data.size()) {
            data[address] = value;
        } else {
            cerr << "Invalid data address: " << address << endl;
        }
    }

    // Read from memory
    int readData(int address) const {
        if (address >= 0 && address < data.size()) {
            return data[address];
        } else {
            cerr << "Invalid data address: " << address << endl;
            return 0;
        }
    }

    // Map logical address to physical address
    int mapAddress(const string& segment, int offset) const {
        if (segments.find(segment) != segments.end()) {
            return segments.at(segment) + offset;
        } else {
            cerr << "Invalid segment: " << segment << endl;
            return -1;
        }
    }

    // Print memory content
    void printMemory() const {
        cout << "Memory Content: " << endl;
        for (int i = 0; i < data.size(); ++i) {
            cout << "[" << i << "]=" << data[i] << " ";
            if (i % 8 == 7) cout << endl;
        }
    }
};

#endif
